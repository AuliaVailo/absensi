/*
SQLyog Job Agent v12.4.1 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 10.1.30-MariaDB : Database - absensi
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`absensi` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `absensi`;

/*Table structure for table `absen_pulang` */

DROP TABLE IF EXISTS `absen_pulang`;

CREATE TABLE `absen_pulang` (
  `nik_nippos` varchar(9) DEFAULT NULL,
  `jam_pulang` datetime DEFAULT CURRENT_TIMESTAMP,
  `tgl_absen_pulang` date DEFAULT NULL,
  KEY `tr_nik` (`nik_nippos`),
  CONSTRAINT `tr_nik` FOREIGN KEY (`nik_nippos`) REFERENCES `pegawai` (`nik_nippos`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `absen_pulang` */

insert  into `absen_pulang` values 
('990407354','2018-02-08 17:15:26','2018-02-08'),
('990405321','2018-02-08 17:15:32','2018-02-08'),
('983391312','2018-02-08 17:15:54','2018-02-08'),
('990407354','2018-02-09 16:48:41','2018-02-09'),
('990407354','2018-02-10 16:12:25','2018-02-10'),
('990407354','2018-02-12 17:19:05','2018-02-12'),
('990407354','2018-02-13 17:24:00','2018-02-13'),
('990407354','2018-02-26 17:26:12','2018-02-26'),
('990407354','2018-02-26 17:26:12','2018-02-26'),
('990407354','2018-03-01 17:07:39','2018-03-01');

/*Table structure for table `absensi_masuk` */

DROP TABLE IF EXISTS `absensi_masuk`;

CREATE TABLE `absensi_masuk` (
  `nik_nippos` varchar(9) DEFAULT NULL,
  `jam_masuk` datetime DEFAULT CURRENT_TIMESTAMP,
  `tgl_absen_masuk` date DEFAULT NULL,
  KEY `tr_nik_nippo` (`nik_nippos`),
  CONSTRAINT `tr_nik_nippo` FOREIGN KEY (`nik_nippos`) REFERENCES `pegawai` (`nik_nippos`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `absensi_masuk` */

insert  into `absensi_masuk` values 
('990407354','2018-02-07 08:12:59','2018-02-07'),
('990405321','2018-02-07 11:42:57','2018-02-07'),
('990407354','2018-02-08 08:34:06','2018-02-08'),
('983391312','2018-02-08 11:11:44','2018-02-08'),
('990407354','2018-02-09 08:21:30','2018-02-09'),
('990407354','2018-02-12 08:32:29','2018-02-12'),
('990407354','2018-02-13 08:55:31','2018-02-13'),
('990407354','2018-02-14 08:24:51','2018-02-14'),
('983391312','2018-02-14 09:32:01','2018-02-14'),
('990407354','2018-02-22 10:35:34','2018-02-22'),
('990407354','2018-02-23 08:30:39','2018-02-23'),
('990407354','2018-02-24 10:26:16','2018-02-24'),
('990405321','2018-02-24 10:42:41','2018-02-24'),
('990407354','2018-02-26 10:42:32','2018-02-26'),
('990407354','2018-03-01 08:40:51','2018-03-01'),
('990407354','2018-03-02 08:07:36','2018-03-02');

/*Table structure for table `pegawai` */

DROP TABLE IF EXISTS `pegawai`;

CREATE TABLE `pegawai` (
  `nik_nippos` varchar(9) NOT NULL,
  `nama` varchar(35) DEFAULT NULL,
  `alamat` text,
  `no_hp` varchar(12) DEFAULT NULL,
  `id_bagian` int(11) DEFAULT NULL,
  `kd_dtkantor` varchar(7) DEFAULT NULL,
  PRIMARY KEY (`nik_nippos`),
  KEY `tr_bagian` (`id_bagian`),
  KEY `tr_kantor` (`kd_dtkantor`),
  CONSTRAINT `tr_bagian` FOREIGN KEY (`id_bagian`) REFERENCES `tm_bagian` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tr_kantor` FOREIGN KEY (`kd_dtkantor`) REFERENCES `td_kantor` (`kode_dtkantor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `pegawai` */

insert  into `pegawai` values 
('623111111','Moch Abd. Khaif',NULL,NULL,10,'62361'),
('623111112','Rudianto',NULL,NULL,10,'62362'),
('623111113','Hendri Febrian Anggana',NULL,NULL,10,'62366'),
('623111114','Tomy',NULL,NULL,10,'62373'),
('623111115','Yudha Ujang Wicaksono',NULL,NULL,3,'62300'),
('623111116','Rina Astiana',NULL,NULL,3,'62300'),
('623111117','Febiani Wulansari',NULL,NULL,3,'62300'),
('623111118','Septyan Dwi Pribadi',NULL,NULL,9,'62300'),
('623111119','Wahyu Eko Prasetyo',NULL,NULL,9,'62300'),
('623111120','Endriko Wibowo',NULL,NULL,9,'62300'),
('623111121','Bayu Among Prabowo',NULL,NULL,9,'62300'),
('623111122','Moch. Abd. Nafid',NULL,NULL,9,'62300'),
('623111123','Dony Febriyanto',NULL,NULL,9,'62300'),
('623111124','Natalia Bayu Nurdian S.',NULL,NULL,3,'62300A2'),
('623111125','Arrum Damayanti',NULL,NULL,3,'62300A1'),
('623111126','Ani Syilfia Fathimah',NULL,NULL,4,'62300'),
('623111127','Diktian Ihsanul Mizan',NULL,NULL,4,'62300'),
('623111128','Kacung',NULL,NULL,9,'62300'),
('623111129','Widya Taufiq F.',NULL,NULL,10,'62373'),
('623111130','Mohamad Asep R',NULL,NULL,4,'62300'),
('623111131','Denny Arie Sandi',NULL,NULL,9,'62300'),
('623111132','Dian Setiana M.',NULL,NULL,7,'62300'),
('623111133','Donny',NULL,NULL,4,'62300'),
('623111134','Rini Astriani',NULL,NULL,4,'62300'),
('623111135','Arica Novia Costanti',NULL,NULL,3,'62300'),
('623111136','Darwinto',NULL,NULL,2,'62300'),
('623111137','Ardi',NULL,NULL,2,'62300'),
('623111138','Dani A.P',NULL,NULL,2,'62300'),
('623111139','Septian M. N.',NULL,NULL,2,'62300'),
('965222603','Karseno',NULL,NULL,10,'62356'),
('965314662','Mucharom',NULL,NULL,9,'62300'),
('966257637','Mohamad Sauji',NULL,NULL,1,'62300'),
('967285355','R. Hari Santoso',NULL,NULL,10,'62352'),
('967294496','Syafrudin Rosyidi',NULL,NULL,10,'62357'),
('967303679','Halili',NULL,NULL,10,'62383'),
('967304544','Widyanto Suhada',NULL,NULL,10,'62366'),
('968323728','Lumadi',NULL,NULL,2,'62300'),
('968334490','Mataji',NULL,NULL,10,'62372'),
('969294980','B. Agus Sukmana',NULL,NULL,10,'62391'),
('969307070','Ikhwan Suhadi',NULL,NULL,10,'62353'),
('969321960','Agus Pratikto',NULL,NULL,10,'62354'),
('970329908','Ratrianto',NULL,NULL,6,'62300'),
('973383938','Sumarto',NULL,NULL,10,'62364'),
('977383982','Suryanto',NULL,NULL,10,'62365B1'),
('978383953','Sus Haryanto',NULL,NULL,10,'62371'),
('980383870','Naning Nur Cahyani',NULL,NULL,10,'62355'),
('980383973','M. Chudori',NULL,NULL,10,'62362'),
('980464386','Apriadi Eko Prrasetyo',NULL,NULL,5,'62300'),
('980464493','Wafiq Aniqoh',NULL,NULL,5,'62300'),
('981397220','Unggul Yudo',NULL,NULL,5,'62300'),
('981464488','Andwika Imaltahda I.',NULL,NULL,9,'62300'),
('982402582','Moch Jusuf Ibrahim Au',NULL,NULL,9,'62300'),
('982464460','Eko Priyo Junianto',NULL,NULL,10,'62382'),
('982475720','Yudi Wibowo',NULL,NULL,10,'62383'),
('983391312','Erwin Wahyu K','TUBAN',NULL,9,'62300'),
('984464440','Fakhrudin Ahmad',NULL,NULL,10,'62354'),
('986396692','Nurul Hidayatin',NULL,NULL,10,'62373'),
('986464454','Bambang Sumarno',NULL,NULL,10,'62353'),
('986464478','Nasyrotul Halimi Arif',NULL,NULL,10,'62357'),
('987412243','Puguh Eka Prasetiya',NULL,NULL,10,'62391'),
('988417327','Indahwati Nawang W.',NULL,NULL,10,'62382'),
('988464391','Meilia Wahyuningtyas',NULL,NULL,6,'62300'),
('988483166','Edi Santoso',NULL,NULL,10,'62365B1'),
('989417232','Maya Sukma K. D',NULL,NULL,10,'62361'),
('989464430','Sujud Wahyuanto',NULL,NULL,10,'62355'),
('989483290','Bachrul Hidayat',NULL,NULL,10,'62371'),
('990405321','Catur Ahaddi Nizar',NULL,NULL,3,'62300'),
('990407354','Moh. Abdul Haq Aulia','Guorejo I, RT 2 RW 5, Sleko','087803166974',2,'62300'),
('990464416','Nurisma Alief Wardhana',NULL,NULL,3,'62300'),
('991464965','Nofita Mayasari',NULL,NULL,4,'62300'),
('991475719','Aris Fatkhurrohman',NULL,NULL,10,'62353'),
('991483522','Sa adatud Daroin',NULL,NULL,3,'62300'),
('992475685','Afifuddin Atsna',NULL,NULL,10,'62372'),
('993415118','Nisrina Athirah Fatin',NULL,NULL,4,'62300'),
('993464403','Akhmad Nasrudin',NULL,NULL,10,'62356'),
('993464427','Mochamad Saiful Ardhi',NULL,NULL,10,'62366');

/*Table structure for table `td_kantor` */

DROP TABLE IF EXISTS `td_kantor`;

CREATE TABLE `td_kantor` (
  `kode_dtkantor` varchar(7) NOT NULL,
  `kode_kantor` varchar(7) DEFAULT NULL,
  `nama_kantor` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`kode_dtkantor`),
  KEY `tr_dt_kantor` (`kode_kantor`),
  CONSTRAINT `tr_dt_kantor` FOREIGN KEY (`kode_kantor`) REFERENCES `tm_kantor` (`kode_kantor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `td_kantor` */

insert  into `td_kantor` values 
('62300','62300','Kantor Pos Tuban'),
('62300A1','62300','Loket Ekstensi KPP Pratama'),
('62300A2','62300','Loket Ekstensi Tuban Kota'),
('62352','62300','Kantor Pos Cabang Jenu'),
('62353','62300','Kantor Pos Cabang Tambakboyo'),
('62354','62300','Kantor Pos Cabang Bancar'),
('62355','62300','Kantor Pos Cabang Merakurak'),
('62356','62300','Kantor Pos Cabang Kerek'),
('62357','62300','Kantor Pos Cabang Montong'),
('62361','62300','Kantor Pos Cabang Jojogan'),
('62362','62300','Kantor Pos Cabang Jatirogo'),
('62364','62300','Kantor Pos Cabang Bangilan'),
('62365B1','62300','Kantor Pos Cabang Senori'),
('62366','62300','Kantor Pos Cabang Parengan'),
('62371','62300','Kantor Pos Cabang Rengel'),
('62372','62300','Kantor Pos Cabang Soko'),
('62373','62300','Kantor Pos Cabang Grabagan'),
('62382','62300','Kantor Pos Cabang Plumpang'),
('62383','62300','Kantor Pos Cabang Widang'),
('62391','62300','Kantor Pos Cabang Palang');

/*Table structure for table `td_validasi` */

DROP TABLE IF EXISTS `td_validasi`;

CREATE TABLE `td_validasi` (
  `tgl_valiasi` datetime DEFAULT CURRENT_TIMESTAMP,
  `nippos` varchar(9) DEFAULT NULL,
  `nama` varchar(35) DEFAULT NULL,
  `tanggal` datetime DEFAULT CURRENT_TIMESTAMP,
  `jam_masuk` varchar(15) DEFAULT NULL,
  `jam_pulang` varchar(15) DEFAULT NULL,
  `ket` text,
  `no_validasi` int(11) DEFAULT NULL,
  KEY `td_validasi` (`tgl_valiasi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `td_validasi` */

/*Table structure for table `tm_bagian` */

DROP TABLE IF EXISTS `tm_bagian`;

CREATE TABLE `tm_bagian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_bagian` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `tm_bagian` */

insert  into `tm_bagian` values 
(1,'Kepala Kantor'),
(2,'Dukungan Umum'),
(3,'Pelayanan'),
(4,'Pemasaran dan Pengembangan Outlet'),
(5,'Keuangan'),
(6,'Akuntansi'),
(7,'PPLA'),
(9,'Prostran'),
(10,'Kepala Kantor Pos Cabang');

/*Table structure for table `tm_informasi` */

DROP TABLE IF EXISTS `tm_informasi`;

CREATE TABLE `tm_informasi` (
  `id_informasi` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) DEFAULT NULL,
  `detail_info` text,
  PRIMARY KEY (`id_informasi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tm_informasi` */

/*Table structure for table `tm_kantor` */

DROP TABLE IF EXISTS `tm_kantor`;

CREATE TABLE `tm_kantor` (
  `kode_kantor` varchar(7) NOT NULL,
  `nama_kantor` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`kode_kantor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tm_kantor` */

insert  into `tm_kantor` values 
('62300','Kantor Pos Tuban'),
('99600','Kantor Pos Merauke');

/*Table structure for table `tm_staff` */

DROP TABLE IF EXISTS `tm_staff`;

CREATE TABLE `tm_staff` (
  `id` int(11) DEFAULT NULL,
  `id_staff` int(11) NOT NULL AUTO_INCREMENT,
  `nama_staff` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_staff`),
  KEY `tr_staff` (`id`),
  CONSTRAINT `tr_staff` FOREIGN KEY (`id`) REFERENCES `tm_bagian` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `tm_staff` */

insert  into `tm_staff` values 
(2,1,'Staff Sarana'),
(5,2,'Kasir'),
(5,3,'Admin SAP'),
(7,4,'Staff UPL'),
(9,5,'Puri Terima'),
(9,6,'Puri Kirim'),
(9,7,'Antaran KPRK'),
(10,8,'Antaran KPC'),
(4,9,'AE'),
(4,10,'Sales'),
(3,11,'Petugas Loket'),
(3,12,'CS'),
(10,13,'Petugas Loket KPC');

/*Table structure for table `tm_validasi` */

DROP TABLE IF EXISTS `tm_validasi`;

CREATE TABLE `tm_validasi` (
  `no_validasi` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal_validasi` datetime DEFAULT CURRENT_TIMESTAMP,
  `status_validasi` int(11) DEFAULT '0',
  PRIMARY KEY (`no_validasi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tm_validasi` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` varchar(9) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `nik_nippos` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user` values 
('623KKP','7bf21b9624b915d484514f12873049d9','966257637'),
('623SDM','7bf21b9624b915d484514f12873049d9','990407354');

/* Trigger structure for table `tm_validasi` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `tr_insert_dt_validasi` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `tr_insert_dt_validasi` AFTER INSERT ON `tm_validasi` FOR EACH ROW BEGIN
    
	INSERT INTO td_validasi (nippos, nama, jam_masuk, jam_pulang, ket, no_validasi)
		SELECT nik_nippos, nama, tanggal, jam_masuk, jam_pulang, new.no_validasi
		FROM v_lap_harian;
    END */$$


DELIMITER ;

/*!50106 set global event_scheduler = 1*/;

/* Event structure for event `auto_validation` */

/*!50106 DROP EVENT IF EXISTS `auto_validation`*/;

DELIMITER $$

/*!50106 CREATE DEFINER=`root`@`localhost` EVENT `auto_validation` ON SCHEDULE EVERY 1 DAY STARTS '2018-02-03 23:55:00' ON COMPLETION PRESERVE ENABLE DO BEGIN
	   INSERT INTO tm_validasi (status_validasi) VALUES('0');
	END */$$
DELIMITER ;

/*Table structure for table `v_absensi_masuk` */

DROP TABLE IF EXISTS `v_absensi_masuk`;

/*!50001 DROP VIEW IF EXISTS `v_absensi_masuk` */;
/*!50001 DROP TABLE IF EXISTS `v_absensi_masuk` */;

/*!50001 CREATE TABLE  `v_absensi_masuk`(
 `nik_nippos` varchar(9) ,
 `nama` varchar(35) ,
 `tgl_absen_masuk` date ,
 `jam_masuk` datetime 
)*/;

/*Table structure for table `v_ansem_pulang` */

DROP TABLE IF EXISTS `v_ansem_pulang`;

/*!50001 DROP VIEW IF EXISTS `v_ansem_pulang` */;
/*!50001 DROP TABLE IF EXISTS `v_ansem_pulang` */;

/*!50001 CREATE TABLE  `v_ansem_pulang`(
 `nik_nippos` varchar(9) ,
 `nama` varchar(35) ,
 `tgl_absen_pulang` date ,
 `jam_pulang` datetime 
)*/;

/*Table structure for table `v_lap_harian` */

DROP TABLE IF EXISTS `v_lap_harian`;

/*!50001 DROP VIEW IF EXISTS `v_lap_harian` */;
/*!50001 DROP TABLE IF EXISTS `v_lap_harian` */;

/*!50001 CREATE TABLE  `v_lap_harian`(
 `nik_nippos` varchar(9) ,
 `nama` varchar(35) ,
 `tanggal` date ,
 `jam_masuk` varchar(8) ,
 `jam_pulang` varchar(8) 
)*/;

/*Table structure for table `v_lap_masuk_hari_ini` */

DROP TABLE IF EXISTS `v_lap_masuk_hari_ini`;

/*!50001 DROP VIEW IF EXISTS `v_lap_masuk_hari_ini` */;
/*!50001 DROP TABLE IF EXISTS `v_lap_masuk_hari_ini` */;

/*!50001 CREATE TABLE  `v_lap_masuk_hari_ini`(
 `nik_nippos` varchar(9) ,
 `nama` varchar(35) ,
 `tgl_absen_masuk` date ,
 `jam_masuk` varchar(8) 
)*/;

/*Table structure for table `v_lap_pul_hari_ini` */

DROP TABLE IF EXISTS `v_lap_pul_hari_ini`;

/*!50001 DROP VIEW IF EXISTS `v_lap_pul_hari_ini` */;
/*!50001 DROP TABLE IF EXISTS `v_lap_pul_hari_ini` */;

/*!50001 CREATE TABLE  `v_lap_pul_hari_ini`(
 `nik_nippos` varchar(9) ,
 `nama` varchar(35) ,
 `tgl_absen_pulang` date ,
 `jam_pulang` varchar(8) 
)*/;

/*Table structure for table `v_report_absensi` */

DROP TABLE IF EXISTS `v_report_absensi`;

/*!50001 DROP VIEW IF EXISTS `v_report_absensi` */;
/*!50001 DROP TABLE IF EXISTS `v_report_absensi` */;

/*!50001 CREATE TABLE  `v_report_absensi`(
 `nik_nippos` varchar(9) ,
 `nama` varchar(35) ,
 `tgl` date ,
 `jam_masuk` datetime ,
 `jam_pulang` datetime 
)*/;

/*Table structure for table `v_user` */

DROP TABLE IF EXISTS `v_user`;

/*!50001 DROP VIEW IF EXISTS `v_user` */;
/*!50001 DROP TABLE IF EXISTS `v_user` */;

/*!50001 CREATE TABLE  `v_user`(
 `user_id` varchar(9) ,
 `password` varchar(100) ,
 `nik_nippos` varchar(9) ,
 `nama` varchar(35) 
)*/;

/*Table structure for table `v_validasi` */

DROP TABLE IF EXISTS `v_validasi`;

/*!50001 DROP VIEW IF EXISTS `v_validasi` */;
/*!50001 DROP TABLE IF EXISTS `v_validasi` */;

/*!50001 CREATE TABLE  `v_validasi`(
 `no_validasi` int(11) ,
 `tanggal_validasi` datetime ,
 `status_validasi` int(11) ,
 `nippos` varchar(9) ,
 `nama` varchar(35) ,
 `tanggal` varchar(10) ,
 `jam_masuk` varchar(15) ,
 `jam_pulang` varchar(15) ,
 `ket` text 
)*/;

/*View structure for view v_absensi_masuk */

/*!50001 DROP TABLE IF EXISTS `v_absensi_masuk` */;
/*!50001 DROP VIEW IF EXISTS `v_absensi_masuk` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_absensi_masuk` AS select `pegawai`.`nik_nippos` AS `nik_nippos`,`pegawai`.`nama` AS `nama`,`absensi_masuk`.`tgl_absen_masuk` AS `tgl_absen_masuk`,`absensi_masuk`.`jam_masuk` AS `jam_masuk` from (`pegawai` left join `absensi_masuk` on((`absensi_masuk`.`nik_nippos` = `pegawai`.`nik_nippos`))) where (`absensi_masuk`.`tgl_absen_masuk` = curdate()) */;

/*View structure for view v_ansem_pulang */

/*!50001 DROP TABLE IF EXISTS `v_ansem_pulang` */;
/*!50001 DROP VIEW IF EXISTS `v_ansem_pulang` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_ansem_pulang` AS select `pegawai`.`nik_nippos` AS `nik_nippos`,`pegawai`.`nama` AS `nama`,`absen_pulang`.`tgl_absen_pulang` AS `tgl_absen_pulang`,`absen_pulang`.`jam_pulang` AS `jam_pulang` from (`pegawai` left join `absen_pulang` on((`absen_pulang`.`nik_nippos` = `pegawai`.`nik_nippos`))) where (`absen_pulang`.`tgl_absen_pulang` = curdate()) */;

/*View structure for view v_lap_harian */

/*!50001 DROP TABLE IF EXISTS `v_lap_harian` */;
/*!50001 DROP VIEW IF EXISTS `v_lap_harian` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_lap_harian` AS select `pegawai`.`nik_nippos` AS `nik_nippos`,`pegawai`.`nama` AS `nama`,`v_lap_masuk_hari_ini`.`tgl_absen_masuk` AS `tanggal`,`v_lap_masuk_hari_ini`.`jam_masuk` AS `jam_masuk`,`v_lap_pul_hari_ini`.`jam_pulang` AS `jam_pulang` from ((`v_lap_masuk_hari_ini` left join `pegawai` on((`v_lap_masuk_hari_ini`.`nik_nippos` = `pegawai`.`nik_nippos`))) left join `v_lap_pul_hari_ini` on((`v_lap_pul_hari_ini`.`nik_nippos` = `pegawai`.`nik_nippos`))) */;

/*View structure for view v_lap_masuk_hari_ini */

/*!50001 DROP TABLE IF EXISTS `v_lap_masuk_hari_ini` */;
/*!50001 DROP VIEW IF EXISTS `v_lap_masuk_hari_ini` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_lap_masuk_hari_ini` AS select `pegawai`.`nik_nippos` AS `nik_nippos`,`pegawai`.`nama` AS `nama`,`v_absensi_masuk`.`tgl_absen_masuk` AS `tgl_absen_masuk`,substr(`v_absensi_masuk`.`jam_masuk`,12,8) AS `jam_masuk` from (`pegawai` left join `v_absensi_masuk` on((`pegawai`.`nik_nippos` = `v_absensi_masuk`.`nik_nippos`))) */;

/*View structure for view v_lap_pul_hari_ini */

/*!50001 DROP TABLE IF EXISTS `v_lap_pul_hari_ini` */;
/*!50001 DROP VIEW IF EXISTS `v_lap_pul_hari_ini` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_lap_pul_hari_ini` AS select `pegawai`.`nik_nippos` AS `nik_nippos`,`pegawai`.`nama` AS `nama`,`v_ansem_pulang`.`tgl_absen_pulang` AS `tgl_absen_pulang`,substr(`v_ansem_pulang`.`jam_pulang`,12,8) AS `jam_pulang` from (`pegawai` left join `v_ansem_pulang` on((`pegawai`.`nik_nippos` = `v_ansem_pulang`.`nik_nippos`))) */;

/*View structure for view v_report_absensi */

/*!50001 DROP TABLE IF EXISTS `v_report_absensi` */;
/*!50001 DROP VIEW IF EXISTS `v_report_absensi` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_report_absensi` AS select `v_absensi_masuk`.`nik_nippos` AS `nik_nippos`,`v_absensi_masuk`.`nama` AS `nama`,`v_absensi_masuk`.`tgl_absen_masuk` AS `tgl`,`v_absensi_masuk`.`jam_masuk` AS `jam_masuk`,`v_ansem_pulang`.`jam_pulang` AS `jam_pulang` from (`v_absensi_masuk` left join `v_ansem_pulang` on(((`v_ansem_pulang`.`nik_nippos` = `v_absensi_masuk`.`nik_nippos`) and (`v_absensi_masuk`.`tgl_absen_masuk` = `v_ansem_pulang`.`tgl_absen_pulang`)))) */;

/*View structure for view v_user */

/*!50001 DROP TABLE IF EXISTS `v_user` */;
/*!50001 DROP VIEW IF EXISTS `v_user` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_user` AS select `user`.`user_id` AS `user_id`,`user`.`password` AS `password`,`user`.`nik_nippos` AS `nik_nippos`,`pegawai`.`nama` AS `nama` from (`user` join `pegawai` on((`user`.`nik_nippos` = `pegawai`.`nik_nippos`))) */;

/*View structure for view v_validasi */

/*!50001 DROP TABLE IF EXISTS `v_validasi` */;
/*!50001 DROP VIEW IF EXISTS `v_validasi` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_validasi` AS select `tm_validasi`.`no_validasi` AS `no_validasi`,`tm_validasi`.`tanggal_validasi` AS `tanggal_validasi`,`tm_validasi`.`status_validasi` AS `status_validasi`,`td_validasi`.`nippos` AS `nippos`,`td_validasi`.`nama` AS `nama`,substr(`td_validasi`.`tanggal`,1,10) AS `tanggal`,`td_validasi`.`jam_masuk` AS `jam_masuk`,`td_validasi`.`jam_pulang` AS `jam_pulang`,`td_validasi`.`ket` AS `ket` from (`td_validasi` join `tm_validasi` on((`td_validasi`.`no_validasi` = `tm_validasi`.`no_validasi`))) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
